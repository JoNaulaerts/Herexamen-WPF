﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerexamenWPF.Model
{
    class EigenschappenGezochtePersoon : BaseModel
    {
        private int id;
        private int eigId;
        private bool waarde;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
                NotifyPropertyChanged();
            }
        }

        public int EigId
        {
            get
            {
                return eigId;
            }

            set
            {
                eigId = value;
                NotifyPropertyChanged();
            }
        }

        public bool Waarde
        {
            get
            {
                return waarde;
            }

            set
            {
                waarde = value;
                NotifyPropertyChanged();
            }
        }
    }
}