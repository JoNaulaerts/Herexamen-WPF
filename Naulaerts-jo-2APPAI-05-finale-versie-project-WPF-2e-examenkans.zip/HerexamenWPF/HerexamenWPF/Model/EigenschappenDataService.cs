﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace HerexamenWPF.Model
{
    class EigenschappenDataService
    {
        // ophalen Connecionstring uit app.config
        private static string connectionString = ConfigurationManager.ConnectionStrings["azure"].ConnectionString;
        //private static string connectionString = ConfigurationManager.ConnectionStrings["local"].ConnectionString;

        // Stap 1
        // IDbConnection aanmaken
        // Connectie met db wordt automatisch geopend
        private static IDbConnection db = new SqlConnection(connectionString);

        public List<Eigenschappen> GetEigenschappen()
        {
            // Stap 2
            // SQL uitschrijven = string
            string sql = "SELECT * FROM Eigenschappen ORDER BY Eigid";

            List<Eigenschappen> eigenschappenList = (List<Eigenschappen>)db.Query<Eigenschappen>(sql);

            // Stap 3 
            // Uitvoeren query
            return eigenschappenList;
        }

        //public void UpdateEigenschappenGezochtPersonage(int id)
        //{
        //    // Stap 2
        //    // SQL uitschrijven = string
        //    string sqlResetEigenschappen = "UPDATE EigenschappenGezochtePersoon SET waarde = 'False'";

        //    string sqlGetEigenschappenTrue = "SELECT EigId FROM PersonageEigenschappen WHERE PersonageId = " + id + "AND WHERE EigAanwezigOfNiet == 'True'";


        //    List<Personage> personageList = (List<Personage>)db.Query<Personage>(sql);
        //    // Stap 3 
        //    // Uitvoeren query

        //    db.Execute(sqlResetEigenschappen);
        }
    }

