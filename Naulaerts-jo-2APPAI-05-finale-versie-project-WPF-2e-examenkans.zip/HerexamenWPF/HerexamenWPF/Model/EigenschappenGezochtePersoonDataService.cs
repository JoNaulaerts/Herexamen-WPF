﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace HerexamenWPF.Model
{
    class EigenschappenGezochtePersoonDataService :BaseModel
    {
        // ophalen Connecionstring uit app.config
        private static string connectionString = ConfigurationManager.ConnectionStrings["azure"].ConnectionString;
        //private static string connectionString = ConfigurationManager.ConnectionStrings["local"].ConnectionString;

        // Stap 1
        // IDbConnection aanmaken
        // Connectie met db wordt automatisch geopend
        private static IDbConnection db = new SqlConnection(connectionString);

        public void VergelijkEigenschapMetGezochtPersonage(Eigenschappen eigenschap)
        {
            try {
            bool waarde;
            List<PersonageEigenschappen> doenNietMeerMeeList;

            // Stap 2
            // SQL uitschrijven = string
            string sqlVergelijkEigenschappen = "SELECT waarde FROM EigenschappenGezochtePersoon Where EigId = " + eigenschap.EigId;

            string sqlFilterEigenschappenTrue = "SELECT * FROM PersonageEigenschappen Where EigId = " + eigenschap.EigId + " AND EigAanwezigOfNiet = 'True'";

            string sqlFilterEigenschappenFalse = "SELECT * FROM PersonageEigenschappen Where EigId = " + eigenschap.EigId + " AND EigAanwezigOfNiet = 'False'";

            // Stap 3 
            // Uitvoeren query

            List<EigenschappenGezochtePersoon> personageEigenschappenList = (List<EigenschappenGezochtePersoon>)db.Query<EigenschappenGezochtePersoon>(sqlVergelijkEigenschappen);
            Console.Write(personageEigenschappenList);

            waarde = personageEigenschappenList[0].Waarde;
            Console.Write(waarde);

            if(waarde == true)
            {
                doenNietMeerMeeList = (List<PersonageEigenschappen>)db.Query<PersonageEigenschappen>(sqlFilterEigenschappenFalse);
                Console.Write(doenNietMeerMeeList);
            }
            else
            {
                doenNietMeerMeeList = (List<PersonageEigenschappen>)db.Query<PersonageEigenschappen>(sqlFilterEigenschappenTrue);
                Console.Write(doenNietMeerMeeList);
            }

            for (int i = 0; i < doenNietMeerMeeList.Count; i++)
            {
                int updatePersonageId = doenNietMeerMeeList[i].PersonageId;

                string sqlUpdatePersonage = "UPDATE NogInSpel SET DoetNogMee = 'False' WHERE PersonageId = " + updatePersonageId;

                db.Execute(sqlUpdatePersonage);
            }
            }
            catch
            {

            }

        }
    }
}
