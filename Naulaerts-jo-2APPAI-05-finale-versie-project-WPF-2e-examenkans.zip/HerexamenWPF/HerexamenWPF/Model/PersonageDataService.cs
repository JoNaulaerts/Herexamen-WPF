﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace HerexamenWPF.Model
{
    class PersonageDataService
    {
        // ophalen Connecionstring uit app.config
        private static string connectionString = ConfigurationManager.ConnectionStrings["azure"].ConnectionString;
        //private static string connectionString = ConfigurationManager.ConnectionStrings["local"].ConnectionString;

        // Stap 1
        // IDbConnection aanmaken
        // Connectie met db wordt automatisch geopend
        private static IDbConnection db = new SqlConnection(connectionString);

        //public List<Personage> GetGezochtPersonage(int id)
        //{
        //    // Stap 2
        //    // SQL uitschrijven = string
        //    string sql = "SELECT * FROM Personage Where PersonageId =" + id;

        //    List<Personage> gezochtPersonage = (List<Personage>)db.Query<Personage>(sql);

        //    // Stap 3 
        //    // Uitvoeren query
        //    return gezochtPersonage;
        //}
        public List<Personage> GetGezochtPersonage(int id)
        {
            // Stap 2
            // SQL uitschrijven = string
            string sql = "SELECT * FROM Personage Where PersonageId =" + id;

            List<Personage> gezochtPersonage = (List<Personage>)db.Query<Personage>(sql);

            // Stap 3 
            // Uitvoeren query
            return gezochtPersonage;
        }

        public List<Personage> GetOverblijvendePersonages()
        {
            // Stap 2
            // SQL uitschrijven = string
            string sqlWieBlijftOver = "SELECT * FROM Personage WHERE PersonageId IN (SELECT PersonageId FROM NogInSpel WHERE DoetNogMee = 'True')";

            // Stap 3 
            // Uitvoeren query
            List<Personage> overlijvendePersonages = (List<Personage>)db.Query<Personage>(sqlWieBlijftOver);

            Console.Write(overlijvendePersonages);


            return overlijvendePersonages;
        }
    }
}
