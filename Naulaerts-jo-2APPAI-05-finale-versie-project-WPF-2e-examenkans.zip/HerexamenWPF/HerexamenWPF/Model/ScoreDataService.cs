﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace HerexamenWPF.Model
{
    class ScoreDataService
    {
        // ophalen Connecionstring uit app.config
        private static string connectionString = ConfigurationManager.ConnectionStrings["azure"].ConnectionString;
        //private static string connectionString = ConfigurationManager.ConnectionStrings["local"].ConnectionString;

        // Stap 1
        // IDbConnection aanmaken
        // Connectie met db wordt automatisch geopend
        private static IDbConnection db = new SqlConnection(connectionString);

        public List<Score> GetAlleScores()
        {
            // Stap 2
            // SQL uitschrijven = string
            string sql = "SELECT * FROM Score ORDER BY AantalGesteldeVragen, Tijd";
            //string sql = "SELECT * FROM Score ORDER BY AantalGesteldeVragen, Tijd";

            List<Score> scoreList = (List<Score>)db.Query<Score>(sql);

            // Stap 3 
            // Uitvoeren query
            return scoreList;
        }
        public void UpdateScore(Score score)
        {
            // SQL statement --> update 
            string sql = "UPDATE Score SET SpelerNaam = @SpelerNaam WHERE id = @id";

            // Uitvoeren SQL statement + doorgeven parametercollectie
            db.Execute(sql, new
            {
                score.Id,
                score.SpelerNaam
            });
        }

        public void DeleteScore(Score score)
        {
            // SQL statement delete 
            string sql = "DELETE Score WHERE id = @id";

            // Uitvoeren SQL statement + doorgeven parametercollectie
            db.Execute(sql, new
            {
                score.Id
            });
        }


        public void InsertScore(string gezochtPersonageNaam, string spelerNaam, int aantalGesteldeVragen, DateTime starttijd)
        {
            DateTime eindTijd = DateTime.Now;
            TimeSpan ts = eindTijd.Subtract(starttijd);


            if (spelerNaam == null)
            {
                spelerNaam = "Anoniem";
            }
            //Console.Write(ts);

            // SQL statement insert

            string sql = "INSERT INTO Score (GezochtPersonageNaam, SpelerNaam, AantalGesteldeVragen) values ('" + gezochtPersonageNaam + "', '" + spelerNaam + "', " + aantalGesteldeVragen + ")";
            //string sql = "INSERT INTO Score (GezochtPersonageNaam, SpelerNaam, AantalGesteldeVragen, Tijd) values ('" + gezochtPersonageNaam + "', '" + spelerNaam + "', " + aantalGesteldeVragen + ", '" + tijdstr + "')";
            //string sql = "INSERT INTO Score (GezochtPersonageNaam, SpelerNaam, AantalGesteldeVragen, Tijd) values ('" + gezochtPersonageNaam + "', '" + spelerNaam + "', " + aantalGesteldeVragen + ", '" + ts + "')";

            //uitvoeren sql statement en doorgeven parametercollectie
            db.Execute(sql);
        }
    }
}
