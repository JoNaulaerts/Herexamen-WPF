﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace HerexamenWPF.Model
{
    class PersonageEigenschappenDataService
    {
        // ophalen Connecionstring uit app.config
        private static string connectionString = ConfigurationManager.ConnectionStrings["azure"].ConnectionString;
        //private static string connectionString = ConfigurationManager.ConnectionStrings["local"].ConnectionString;

        // Stap 1
        // IDbConnection aanmaken
        // Connectie met db wordt automatisch geopend
        private static IDbConnection db = new SqlConnection(connectionString);


        public void UpdateEigenschappenGezochtPersonage(int id)
        {

            int updateEigenschapId;
            // Stap 2
            // SQL uitschrijven = string
            string sqlResetEigenschappen = "UPDATE EigenschappenGezochtePersoon SET waarde = 'False'";

            string sqlGetEigenschappenTrue = "SELECT * FROM PersonageEigenschappen WHERE EigAanwezigOfNiet = 'True' AND PersonageId = " + id;

            //string sqlUpdateEigenschappenGezochtPersonage = "UPDATE EigenschappenGezochtePersoon SET waarde = 'True' WHERE EigId = " + updateEigenschapId;


            // Stap 3 
            // Uitvoeren query

            db.Execute(sqlResetEigenschappen);

            List<PersonageEigenschappen> personageEigenschappenList = (List<PersonageEigenschappen>)db.Query<PersonageEigenschappen>(sqlGetEigenschappenTrue);
            Console.Write(personageEigenschappenList);

            for (int i = 0; i < personageEigenschappenList.Count; i++)
            {
                updateEigenschapId = personageEigenschappenList[i].EigId;

                string sqlUpdateEigenschappenGezochtPersonage = "UPDATE EigenschappenGezochtePersoon SET waarde = 'True' WHERE EigId = " + updateEigenschapId;

                db.Execute(sqlUpdateEigenschappenGezochtPersonage);
            }
        }
    }
}


