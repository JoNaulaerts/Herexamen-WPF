﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerexamenWPF.Model
{
    class NogInSpel : BaseModel
    {
        private int id;
        private int personageId;
        private bool doetNogMee;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
                NotifyPropertyChanged();
            }
        }

        public int PersonageId
        {
            get
            {
                return personageId;
            }

            set
            {
                personageId = value;
                NotifyPropertyChanged();
            }
        }

        public bool DoetNogMee
        {
            get
            {
                return doetNogMee;
            }

            set
            {
                doetNogMee = value;
                NotifyPropertyChanged();
            }
        }
    }
}
