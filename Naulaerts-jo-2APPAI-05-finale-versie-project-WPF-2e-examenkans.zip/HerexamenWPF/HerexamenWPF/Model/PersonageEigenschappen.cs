﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerexamenWPF.Model
{
    class PersonageEigenschappen : BaseModel
    {
        private int id;
        private int personageId;
        private int eigId;
        private bool eigAanwezigOfNiet;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
                NotifyPropertyChanged();
            }
        }

        public int PersonageId
        {
            get
            {
                return personageId;
            }

            set
            {
                personageId = value;
                NotifyPropertyChanged();
            }
        }

        public int EigId
        {
            get
            {
                return eigId;
            }

            set
            {
                eigId = value;
                NotifyPropertyChanged();
            }
        }

        public bool EigAanwezigOfNiet
        {
            get
            {
                return eigAanwezigOfNiet;
            }

            set
            {
                eigAanwezigOfNiet = value;
                NotifyPropertyChanged();
            }
        }
    }
}
