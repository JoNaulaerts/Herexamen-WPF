﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerexamenWPF.Model
{
    class Eigenschappen : BaseModel
    {
        private int id;
        private int eigId;
        private string eigNaam;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
                NotifyPropertyChanged();
            }
        }

        public int EigId
        {
            get
            {
                return eigId;
            }

            set
            {
                eigId = value;
                NotifyPropertyChanged();
            }
        }

        public string EigNaam
        {
            get
            {
                return eigNaam;
            }

            set
            {
                eigNaam = value;
                NotifyPropertyChanged();
            }
        }
    }


}
