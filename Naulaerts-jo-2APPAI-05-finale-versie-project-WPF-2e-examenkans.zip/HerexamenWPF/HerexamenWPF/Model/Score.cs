﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerexamenWPF.Model
{
    class Score : BaseModel
    {
        private int id;
        private string gezochtPersonageNaam;
        private string spelerNaam;
        private int aantalGesteldeVragen;
        private DateTime tijd;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
                NotifyPropertyChanged();
            }
        }

        public string GezochtPersonageNaam
        {
            get
            {
                return gezochtPersonageNaam;
            }

            set
            {
                gezochtPersonageNaam = value;
                NotifyPropertyChanged();
            }
        }

        public string SpelerNaam
        {
            get
            {
                return spelerNaam;
            }

            set
            {
                spelerNaam = value;
                NotifyPropertyChanged();
            }
        }

        public int AantalGesteldeVragen
        {
            get
            {
                return aantalGesteldeVragen;
            }

            set
            {
                aantalGesteldeVragen = value;
                NotifyPropertyChanged();
            }
        }

        public DateTime Tijd
        {
            get
            {
                return tijd;
            }

            set
            {
                tijd = value;
                NotifyPropertyChanged();
            }
        }
    }
}
