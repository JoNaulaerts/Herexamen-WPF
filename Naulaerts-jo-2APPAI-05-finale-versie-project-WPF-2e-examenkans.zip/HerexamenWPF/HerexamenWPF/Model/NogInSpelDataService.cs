﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace HerexamenWPF.Model
{
    class NogInSpelDataService: BaseModel
    {
        // ophalen Connecionstring uit app.config
        private static string connectionString = ConfigurationManager.ConnectionStrings["azure"].ConnectionString;
        //private static string connectionString = ConfigurationManager.ConnectionStrings["local"].ConnectionString;

        // Stap 1
        // IDbConnection aanmaken
        // Connectie met db wordt automatisch geopend
        private static IDbConnection db = new SqlConnection(connectionString);

        public List<NogInSpel> GetPersonagesNogInSpel()
        {
            // Stap 2
            // SQL uitschrijven = string
            string sql = "SELECT * FROM NogInSpel Where DoetNogMee = 'True' ORDER BY Personageid";

            List<NogInSpel> personageList = (List<NogInSpel>)db.Query<NogInSpel>(sql);

            // Stap 3 
            // Uitvoeren query
            return personageList;
        }

        public void ResetNogInSpel()
        {
            // Stap 2
            // SQL uitschrijven = string
            string sqlResetNogInSpel = "UPDATE NogInSpel SET DoetNogMee = 'True'";
        
            // Stap 3 
            // Uitvoeren query

            db.Execute(sqlResetNogInSpel);
        }
    }
}
