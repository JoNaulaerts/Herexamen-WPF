﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using HerexamenWPF.Extensions;
using HerexamenWPF.Messages;
using HerexamenWPF.Model;

namespace HerexamenWPF.ViewModel
{
    class ResultaatWindowViewModel : BaseViewModel
    {
        private DialogService dialogService;
        public Personage gezochtPersonage { get; set;}
        public int aantalGesteldeVragen { get; set;}
        public List<NogInSpel> nogInSpelList { get; set;}

        public ResultaatWindowViewModel()
        {
            dialogService = new DialogService();

            Messenger.Default.Register<Personage>(this, OnGezochtPersonageReceived);
            Messenger.Default.Register<List<NogInSpel>>(this, OnNogInSpelReceived);
            Messenger.Default.Register<int>(this, OnAantalGesteldeVragenReceived);


            KoppelenCommands();
        }

        private void KoppelenCommands()
        {
            NaarStelEenVraagCommand = new BaseCommand(NaarStelEenVraag);
        }

        public ICommand NaarStelEenVraagCommand { get; set; }

        private void NaarStelEenVraag()
        {
            Messenger.Default.Send<UpdateFinishedMessage>(new UpdateFinishedMessage("vraag"));
        }

        private void OnGezochtPersonageReceived(Personage personage)
        {
            gezochtPersonage = personage;
            //Console.Write(personage);
        }
        private void OnNogInSpelReceived(List<NogInSpel> nogIn)
        {
            nogInSpelList = nogIn;
            //Console.Write(nogIn);
        }

        private void OnAantalGesteldeVragenReceived(int aantal)
        {
            aantalGesteldeVragen = aantal;
            //Console.Write(aantal);
        }
    }
}
