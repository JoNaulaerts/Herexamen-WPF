﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using HerexamenWPF.Extensions;
using HerexamenWPF.Messages;
using HerexamenWPF.Model;

namespace HerexamenWPF.ViewModel
{
    class ScorebordWindowViewModel : BaseViewModel
    {
        private DialogService dialogService;
        public ScorebordWindowViewModel()
        {
            LeesSpelersIn();
            KoppelenCommands();
        }

        private ObservableCollection<Score> spelers;
        public ObservableCollection<Score> Spelers
        {
            get
            {
                return spelers;
            }

            set
            {
                spelers = value;
                NotifyPropertyChanged();
            }
        }

        private Score currentSpeler;
        public Score CurrentSpeler
        {
            get
            {
                if (currentSpeler == null)
                {
                    currentSpeler = new Score();
                }
                return currentSpeler;
            }

            set
            {
                currentSpeler = value;
                NotifyPropertyChanged();
            }
        }

        private void KoppelenCommands()
        {
            WijzigenCommand = new BaseCommand(WijzigenSpeler);
            VerwijderenCommand = new BaseCommand(VerwijderenSpeler);
            TerugNaarMenuCommand = new BaseCommand(TerugNaarMenu);
            RefreshDeLijstCommand = new BaseCommand(RefreshDeLijst);
            //ToevoegenCommand = new BaseCommand(ToevoegenContactPersoon);

        }

        public ICommand VerwijderenCommand { get; set; }
        public ICommand WijzigenCommand { get; set; }
        //public ICommand ToevoegenCommand { get; set; }
        public ICommand TerugNaarMenuCommand { get; set; }
        public ICommand RefreshDeLijstCommand { get; set; }

        private void LeesSpelersIn()
        {
            ScoreDataService scoreDS = new ScoreDataService();
            Spelers = new ObservableCollection<Score>(scoreDS.GetAlleScores());
        }

        public void WijzigenSpeler()
        {
            if (CurrentSpeler != null)
            {
                ScoreDataService scoreDS = new ScoreDataService();
                scoreDS.UpdateScore(CurrentSpeler);

                //Refresh
                LeesSpelersIn();
            }
        }

        //public void ToevoegenContactPersoon()
        //{
        //    ContactPersoonDataService contactDS = new ContactPersoonDataService();
        //    contactDS.InsertContactPersoon(CurrentContact);

        //    // refresh
        //    LeesContactPersonen();
        //}


        public void VerwijderenSpeler()
        {
            if (CurrentSpeler != null)
            {
                ScoreDataService scoreDS = new ScoreDataService();
                scoreDS.DeleteScore(CurrentSpeler);

                //Refresh
                LeesSpelersIn();
            }
        }
        public void TerugNaarMenu()
        {
            string volgendePagina = "splash";
            Messenger.Default.Send<UpdateFinishedMessage>(new UpdateFinishedMessage(volgendePagina));
        }

        public void RefreshDeLijst()
        {
            LeesSpelersIn();
        }
    }
}
