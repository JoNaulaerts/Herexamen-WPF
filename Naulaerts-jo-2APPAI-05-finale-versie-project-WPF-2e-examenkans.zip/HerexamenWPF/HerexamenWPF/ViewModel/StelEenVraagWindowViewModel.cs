﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using HerexamenWPF.Extensions;
using HerexamenWPF.Messages;
using HerexamenWPF.Model;

namespace HerexamenWPF.ViewModel
{
    class StelEenVraagWindowViewModel : BaseViewModel
    {
        private DialogService dialogService;
        public Personage gezochtPersonage;
        //public List<Eigenschappen> eigenschappenList;
        //public List<Personage> personageList;
        public List<NogInSpel> nogInSpelList;
        public int aantalGesteldeVragen;
        private DateTime startTijd;

        public StelEenVraagWindowViewModel()
        {

            dialogService = new DialogService();

            Messenger.Default.Register<Personage>(this, OnGezochtPersonageReceived);

            //lijst van personages inladen
            NogInSpelDataService nogInSpelDS = new NogInSpelDataService();
            nogInSpelList = nogInSpelDS.GetPersonagesNogInSpel();
            //Console.Write(nogInSpelList);


            //nogInSpelDS.ResetNogInSpel();
            LeesAlleVragenUit();
            LeesAllePersonagesUit();
            KoppelenCommands();
            Messenger.Default.Register<UpdateFinishedMessage>(this, OnMessageReceived);
            Messenger.Default.Register<DateTime>(this, OnStartTijdReceived);
        }

        private void OnStartTijdReceived(DateTime startTijdSpel)
        {
            startTijd = startTijdSpel;
            Console.Write(startTijdSpel);
        }

        private void OnMessageReceived(UpdateFinishedMessage message)
        {
            //na update mag detailvenster sluiten
            dialogService.CloseResultaatDialog();
        }


        private ObservableCollection<Eigenschappen> vragen; //alle eigenschappen
        public ObservableCollection<Eigenschappen> Vragen
        {
            get
            {
                return vragen;
            }

            set
            {
                vragen = value;
                NotifyPropertyChanged();
            }
        }

        private Eigenschappen currentVraag; //1 geselecteerde eigenschap
        public Eigenschappen CurrentVraag
        {
            get
            {
                if (currentVraag == null)
                {
                    currentVraag = new Eigenschappen();
                }
                return currentVraag;
            }

            set
            {
                currentVraag = value;
                NotifyPropertyChanged();
            }
        }

        private ObservableCollection<Personage> personages; //alle personages
        public ObservableCollection<Personage> Personages
        {
            get
            {
                return personages;
            }

            set
            {
                personages = value;
                NotifyPropertyChanged();
            }
        }

        private void KoppelenCommands()
        {
            StelEenVraagCommand = new BaseCommand(UpdateStelEenVraag);
        }

        public ICommand StelEenVraagCommand { get; set; }

        public void UpdateStelEenVraag()
        {
            if (CurrentVraag != null)
            {
                aantalGesteldeVragen += 1;
                Console.Write(aantalGesteldeVragen);

                EigenschappenGezochtePersoonDataService eigenschappenGezochtePersoonDS = new EigenschappenGezochtePersoonDataService();
                eigenschappenGezochtePersoonDS.VergelijkEigenschapMetGezochtPersonage(CurrentVraag);

                NogInSpelDataService nogInSpelDS = new NogInSpelDataService();
                List<NogInSpel> nogInSpel = nogInSpelDS.GetPersonagesNogInSpel();

                if (nogInSpel.Count == 1)
                {
                    NotifyPropertyChanged();
                    Messenger.Default.Send<int>(aantalGesteldeVragen);


                    Messenger.Default.Send<UpdateFinishedMessage>(new UpdateFinishedMessage("gevonden"));


                }

                else
                {

                    Messenger.Default.Send<List<NogInSpel>>(nogInSpel);
                    Messenger.Default.Send<int>(aantalGesteldeVragen);
                    //refresh
                    LeesAlleVragenUit();
                    LeesAllePersonagesUit();
                    
                    Messenger.Default.Send<UpdateFinishedMessage>(new UpdateFinishedMessage("resultaat"));
                    //dialogService.ShowResultaatDialog();
                }


            }
        }

        private void LeesAlleVragenUit() //alle eigenschappen
        {
            EigenschappenDataService vraagDS = new EigenschappenDataService();
            Vragen = new ObservableCollection<Eigenschappen>(vraagDS.GetEigenschappen());

            NotifyPropertyChanged();
        }

        private void LeesAllePersonagesUit() //alle personages
        {
            PersonageDataService personageDS = new PersonageDataService();
            Personages = new ObservableCollection<Personage>(personageDS.GetOverblijvendePersonages());

            NotifyPropertyChanged();
        }

        private void OnGezochtPersonageReceived(Personage personage)
        {
            gezochtPersonage = personage;
            //Console.Write(personage);
        }

        //private void OnEigenschappenListReceived(List<Eigenschappen> eigenscahppenlijst)
        //{
        //    eigenschappenList = eigenscahppenlijst;
        //    Console.Write(eigenscahppenlijst);
        //}

    }
}
