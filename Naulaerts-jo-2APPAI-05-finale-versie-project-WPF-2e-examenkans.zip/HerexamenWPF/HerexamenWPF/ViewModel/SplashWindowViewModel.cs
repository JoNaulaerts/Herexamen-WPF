﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using HerexamenWPF.Extensions;
using HerexamenWPF.Messages;
using HerexamenWPF.Model;

namespace HerexamenWPF.ViewModel
{
    class SplashWindowViewModel: BaseViewModel
    {
        private DialogService dialogService;

        private Personage selectedPersonage;
        private Personage gezochtPersonage;
        private DateTime startTijd;

        public Personage SelectedPersonage
        {
            get
            {
                return selectedPersonage;
            }
            set
            {
                selectedPersonage = value;
                NotifyPropertyChanged();
            }
        }
        public SplashWindowViewModel()
        {
            dialogService = new DialogService();
            KoppelenCommands();



            Messenger.Default.Register<UpdateFinishedMessage>(this, OnMessageReceived);
        }

        private void KoppelenCommands()
        {
            KiesEenGezochtPersoonCommand = new BaseCommand(KiesGezochtePersoon);
            NaarScorebordCommand = new BaseCommand(NaarScorebord);
        }

        public ICommand KiesEenGezochtPersoonCommand { get; set; }
        public ICommand NaarScorebordCommand { get; set; }

        private void KiesGezochtePersoon()
        {
            PersonageDataService gezochtDS = new PersonageDataService();
            PersonageEigenschappenDataService eigenschappenDS = new PersonageEigenschappenDataService();
            NogInSpelDataService nogInSpelDS = new NogInSpelDataService();

            nogInSpelDS.ResetNogInSpel();


            Random rnd = new Random();
            int randomId = rnd.Next(1, 25); // 25 wordt recordcount + 1

            List<Personage> gezochtPersonageList = gezochtDS.GetGezochtPersonage(randomId);
            gezochtPersonage = gezochtPersonageList[0];
            //Console.Write(gezochtPersonage);

            eigenschappenDS.UpdateEigenschappenGezochtPersonage(randomId);

            startTijd = DateTime.Now;

            Messenger.Default.Send<DateTime>(startTijd);

            Messenger.Default.Send<Personage>(gezochtPersonage);


            //startTijd = DateTime.Now;

            //Messenger.Default.Send<DateTime>(startTijd);

            dialogService.ShowStelEenVraagDialog();


        }
        private void NaarScorebord()
        {
            
            dialogService.ShowScorebordDialog();
        }

        private void OnMessageReceived(UpdateFinishedMessage message)
        {
            if (message.volgendePagina == "splash")
            {
                dialogService.CloseScorebordDialog();
                dialogService.CloseGevondenDialog();
            }
            if (message.volgendePagina == "resultaat")
            {
                dialogService.CloseStelEenVraagDialog();
                dialogService.ShowResultaatDialog();
            }
            if (message.volgendePagina == "vraag")
            {
                dialogService.CloseResultaatDialog();
                dialogService.ShowStelEenVraagDialog();
            }
            if (message.volgendePagina == "gevonden")
            {
                dialogService.CloseStelEenVraagDialog();
                dialogService.ShowGevondenDialog();
            }
        }
    }
}
