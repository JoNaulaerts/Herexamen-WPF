﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using HerexamenWPF.Extensions;
using HerexamenWPF.Messages;
using HerexamenWPF.Model;

namespace HerexamenWPF.ViewModel
{
    class GevondenWindowViewModel : BaseViewModel
    {
        private DialogService dialogService;
        public Personage gezochtPersonage { get; set;}
        public int aantalGesteldeVragen { get; set; }
        public string naamSpeler { get; set; }

        public DateTime startTijd;

        public GevondenWindowViewModel()
        {
            dialogService = new DialogService();



            Messenger.Default.Register<Personage>(this, OnGezochtPersonageReceived);
            Messenger.Default.Register<int>(this, OnAantalGesteldeVragenReceived);
            Messenger.Default.Register<DateTime>(this, OnStartTijdReceived);
            KoppelenCommands();
        }

        private void KoppelenCommands()
        {
            TerugNaarMenuCommand = new BaseCommand(TerugNaarMenu);
        }

        public ICommand TerugNaarMenuCommand { get; set; }

        private void TerugNaarMenu()
        {

            //Console.Write(naamSpeler);

            string gezocht = gezochtPersonage.Naam;

            ScoreDataService scoreDS = new ScoreDataService();
            scoreDS.InsertScore(gezocht, naamSpeler, aantalGesteldeVragen, startTijd);

            Messenger.Default.Send<UpdateFinishedMessage>(new UpdateFinishedMessage("splash"));
        }
        private void OnGezochtPersonageReceived(Personage personage)
        {
            gezochtPersonage = personage;
            Console.Write(personage);
        }

        

        private void OnAantalGesteldeVragenReceived(int aantalVragen)
        {
            aantalGesteldeVragen = aantalVragen;
            Console.Write(aantalVragen);
        }

        private void OnStartTijdReceived(DateTime startTijdSpel)
        {
            startTijd = startTijdSpel;
            Console.Write(startTijdSpel);
        }
    }
}
