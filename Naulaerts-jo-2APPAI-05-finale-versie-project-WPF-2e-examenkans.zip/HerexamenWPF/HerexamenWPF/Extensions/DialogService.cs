﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using HerexamenWPF.View;
using HerexamenWPF.Model;
using HerexamenWPF.Extensions;

namespace HerexamenWPF.Extensions
{
    class DialogService
    {
        Window StelEenVraagView = null;
        Window ResultaatView = null;
        Window GevondenView = null;
        Window SplashView = null;
        Window ScorebordView = null;

        public DialogService() { }

        public void ShowStelEenVraagDialog()
        {
            StelEenVraagView = new StelEenVraagWindow();
            StelEenVraagView.ShowDialog();
        }

        public void CloseStelEenVraagDialog()
        {
            if (StelEenVraagView != null)
                StelEenVraagView.Close();
        }

        public void ShowResultaatDialog()
        {
            ResultaatView = new ResultaatWindow();
            ResultaatView.ShowDialog();
        }

        public void CloseResultaatDialog()
        {
            if (ResultaatView != null)
                ResultaatView.Close();
        }

        public void ShowGevondenDialog()
        {
            GevondenView = new GevondenWindow();
            GevondenView.ShowDialog();
        }

        public void CloseGevondenDialog()
        {
            if (GevondenView != null)
                GevondenView.Close();
        }

        public void ShowSplashDialog()
        {
            SplashView = new SplashWindow();
            SplashView.ShowDialog();
        }

        public void CloseSplashDialog()
        {
            if (SplashView != null)
                SplashView.Close();
        }
        public void ShowScorebordDialog()
        {
            ScorebordView = new ScorebordWindow();
            ScorebordView.ShowDialog();
        }

        public void CloseScorebordDialog()
        {
            if (ScorebordView != null)
                ScorebordView.Close();
        }
    }
}
