﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HerexamenWPF.ViewModel;

namespace HerexamenWPF.Extensions
{
    class ViewModelLocator
    {
        private static StelEenVraagWindowViewModel stelEenVraagWindowViewModel = new StelEenVraagWindowViewModel();
        private static ResultaatWindowViewModel resultaatWindowViewModel = new ResultaatWindowViewModel();
        private static GevondenWindowViewModel gevondenWindowViewModel = new GevondenWindowViewModel();
        private static SplashWindowViewModel splashWindowViewModel = new SplashWindowViewModel();
        private static ScorebordWindowViewModel scorebordWindowViewModel = new ScorebordWindowViewModel();


        public static StelEenVraagWindowViewModel StelEenVraagWindowViewModel
        {
            get
            {
                return stelEenVraagWindowViewModel;
            }
        }

        public static ResultaatWindowViewModel ResultaatWindowViewModel
        {
            get
            {
                return resultaatWindowViewModel;
            }
        }

        public static GevondenWindowViewModel GevondenWindowViewModel
        {
            get
            {
                return gevondenWindowViewModel;
            }
        }

        public static SplashWindowViewModel SplashWindowViewModel
        {
            get
            {
                return splashWindowViewModel;
            }
        }

        public static ScorebordWindowViewModel ScorebordWindowViewModel
        {
            get
            {
                return scorebordWindowViewModel;
            }
        }
    }
}
